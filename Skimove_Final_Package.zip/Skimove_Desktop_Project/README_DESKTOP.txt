Skimove Desktop project skeleton. Open in Visual Studio and publish using Build_EXE.bat or GitHub Actions workflow.
