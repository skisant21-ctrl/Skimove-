Skimove Mobile skeleton (MAUI). Build via Visual Studio MAUI or use GitHub Actions workflow included.
