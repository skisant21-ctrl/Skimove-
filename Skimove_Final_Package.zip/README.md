# Skimove - Final Package

This package contains desktop and mobile project skeletons, workflows and resources.

Follow the included README files to build and publish.
